# Zoho CRM × Anthropic Customer Support Agent

A drop-in integration that adds full Zoho CRM capabilities to the [anthropic-quickstarts/customer-support-agent](https://github.com/anthropics/anthropic-quickstarts/tree/main/customer-support-agent).

## What it does

| Feature | How it works |
|---|---|
| **Pull CRM contact data** | Auto-detects email in chat → looks up Contact/Lead in Zoho CRM → greets user by name |
| **Create/update records** | Creates new Leads from conversation, updates fields when users share new info |
| **Log activities** | At end of each session, logs a summary Task back into the CRM record |
| **Analyze pipeline** | Answers questions about deals, stages, revenue using live CRM data |

## Architecture

```
User → Next.js Chat UI
           ↓
    /api/chat route (Claude claude-sonnet-4-20250514)
           ↓ tool_use
    lib/zoho-tools.js (tool definitions + handlers)
           ↓
    lib/zoho-crm.js (Zoho REST API v7 client)
           ↓
    Zoho CRM
```

Claude runs an **agentic tool-use loop** — it can call multiple CRM tools in sequence before forming a final response (e.g., look up contact → fetch their deals → respond with context).

## Setup

### 1. Clone the quickstart and add this integration

```bash
git clone https://github.com/anthropics/anthropic-quickstarts.git
cd anthropic-quickstarts/customer-support-agent
```

Copy these files into the project:
```
lib/zoho-crm.js          → lib/zoho-crm.js
lib/zoho-tools.js        → lib/zoho-tools.js
app/api/chat/route.js    → app/api/chat/route.js   (replaces original)
components/ZohoCRMSupportChat.jsx → components/ZohoCRMSupportChat.jsx
app/page.jsx             → app/page.jsx             (replaces original)
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set up environment variables

```bash
cp .env.local.example .env.local
```

Fill in:
```env
ANTHROPIC_API_KEY=sk-ant-...
ZOHO_CLIENT_ID=...
ZOHO_CLIENT_SECRET=...
ZOHO_REFRESH_TOKEN=...
ZOHO_REGION=com
```

### 4. Get Zoho OAuth credentials

1. Go to [https://api-console.zoho.com/](https://api-console.zoho.com/)
2. Create a **Self Client**
3. Use this scope:
   ```
   ZohoCRM.modules.ALL,ZohoCRM.settings.modules.READ,ZohoCRM.settings.fields.READ
   ```
4. Generate a **Refresh Token** via the Authorization Code flow

### 5. Run

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Claude Tools Available

| Tool | Trigger |
|---|---|
| `lookup_contact_by_email` | User shares email |
| `get_customer_deals` | User asks about their orders/deals |
| `create_lead` | New user not found in CRM |
| `update_crm_record` | User provides updated info |
| `log_conversation_activity` | End of every session |
| `get_pipeline_deals` | User/agent asks about pipeline |
| `search_crm` | General CRM search |

## Example Conversations

> User: "Hi, my email is john@acme.com, I have a question about my deal"
> → Claude looks up john@acme.com → finds Contact "John Smith" → fetches linked deals → "Hi John! I can see you have 2 open deals..."

> User: "Can you update my phone to +1-555-9876?"
> → Claude confirms → calls `update_crm_record` → updates Contact → "Done! Your phone number has been updated."

> User: "How many deals are in the Proposal stage?"
> → Claude calls `get_pipeline_deals` with stage="Proposal/Price Quote" → "You have 4 deals in Proposal stage totalling $48,500."
